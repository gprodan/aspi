#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Teste automate pentru control_nivel_rezervor.py
Rulare:  python test_control.py          (din același folder cu aplicația)

T-U1 … T-U6  teste unitare (model, PID, indicatori de calitate)
T-I1         test de integrare gateway snap7 cu un PLC emulat (server S7 local, port 1102)
"""
import math
import threading
import time
import unittest
import queue

import control_nivel_rezervor as C


def closed_loop(kp=5.0, ki=0.3, kd=1.0, sp=60.0, h0=10.0, drain=0.2, T=60.0, dt=0.01, disturb=None):
    """Simulează bucla închisă locală. disturb = (t, drain_nou). Returnează (metrici, istoric)."""
    m, pid, met = C.TankModel(h0), C.PID(kp, ki, kd), C.StepMetrics()
    pid.reset(m.h)
    t, hist = 0.0, []
    while t < T:
        d = disturb[1] if disturb and t >= disturb[0] else drain
        u = pid.update(sp, m.h, dt)
        m.step(u, d, dt)
        t += dt
        met.observe(t, sp, m.h, True)
        hist.append((t, m.h, u))
    return met.summary(t), hist


class TestModel(unittest.TestCase):
    def test_U1_echilibru(self):
        """T-U1: la u0 = 1.2·d·√h0 / 8 nivelul rămâne constant."""
        h0, d = 60.0, 0.2
        m = C.TankModel(h0)
        u0 = C.TankModel.KOUT * d * math.sqrt(h0) / C.TankModel.QIN_MAX
        for _ in range(10000):
            m.step(u0, d, 0.01)
        self.assertAlmostEqual(m.h, h0, places=3)

    def test_U2_limite(self):
        """T-U2: nivelul rămâne în [0, 100] % la comenzi extreme."""
        m = C.TankModel(50)
        for _ in range(5000):
            m.step(1.0, 0.0, 0.05)
        self.assertEqual(m.h, 100.0)
        for _ in range(5000):
            m.step(0.0, 1.0, 0.05)
        self.assertEqual(m.h, 0.0)


class TestPID(unittest.TestCase):
    def test_U3_raspuns_treapta(self):
        """T-U3: răspuns la treaptă 10 -> 60 %: suprareglaj < 10 %, eroare staționară < 0.5 %."""
        s, hist = closed_loop()
        self.assertLess(abs(hist[-1][1] - 60.0), 0.5)
        self.assertLess(float(s["os"].split()[0]), 10.0)

    def test_U4_perturbatie(self):
        """T-U4: rejecția perturbației (golire 0.2 -> 0.5 la t = 40 s) — nivelul revine la consemn."""
        _, hist = closed_loop(T=120, disturb=(40, 0.5))
        self.assertLess(abs(hist[-1][1] - 60.0), 0.5)

    def test_U5_saturatie_antiwindup(self):
        """T-U5: ieșirea rămâne în [0, 1]; după saturație prelungită integrala nu explodează."""
        pid = C.PID(5, 0.3, 1)
        pid.reset(0)
        for _ in range(10000):          # eroare mare, menținută 100 s
            u = pid.update(100, 0, 0.01)
            self.assertTrue(0.0 <= u <= 1.0)
        self.assertLess(abs(pid.i), 1.0 / 0.3 + 1e-6)

    def test_U6_fara_lovitura_derivativa(self):
        """T-U6: la salt de consemn, termenul D nu produce un vârf (derivata pe măsură)."""
        pid = C.PID(0, 0, 10)
        pid.reset(50)
        pid.update(50, 50, 0.1)
        pid.update(90, 50, 0.1)         # salt de consemn, măsura neschimbată
        self.assertAlmostEqual(pid.d_term, 0.0, places=9)


class TestGatewayS7(unittest.TestCase):
    def test_I1_gateway_plc_emulat(self):
        """T-I1: gateway S7Link + PLC emulat (PI + watchdog): nivelul atinge consemnul,
        iar la deconectare PLC-ul semnalează CommFault."""
        try:
            import snap7
            from snap7.util import get_bool, get_int, get_real, set_bool, set_real
        except ImportError:
            self.skipTest("python-snap7 nu este instalat")
        db = bytearray(26)
        srv = snap7.server.Server()
        srv.register_area(snap7.type.SrvArea.DB, 1, db)
        srv.start(tcp_port=1102)
        stop = threading.Event()

        def plc():                       # „OB30” emulat la 100 ms
            i, last, cnt = 0.0, None, 0
            while not stop.is_set():
                b = bytearray(db)
                lvl, sp, hb = get_real(b, 0), get_real(b, 4), get_int(b, 12)
                run, es = get_bool(b, 14, 0), get_bool(b, 14, 1)
                cnt = 0 if hb != last else cnt + 1
                last = hb
                fault = cnt > 20
                if run and not es and not fault:
                    e = sp - lvl
                    i = max(-300, min(300, i + e * 0.1))
                    out = max(0.0, min(100.0, 5 * e + 0.3 * i))
                else:
                    i, out = 0.0, 0.0
                set_real(b, 16, out)
                set_bool(b, 20, 0, fault)
                db[15:21] = b[15:21]
                time.sleep(0.1)

        threading.Thread(target=plc, daemon=True).start()
        q = queue.Queue()
        link = C.S7Link(q)
        link.start("127.0.0.1", 0, 1, 1, 1102)
        m, d, t0 = C.TankModel(10), None, time.time()
        try:
            while time.time() - t0 < 30:
                while not q.empty():
                    k, v = q.get()
                    if k == "plc":
                        d = v
                u = 0.0 if not d or d["comm_fault"] else d["fill"] / 100
                for _ in range(5):
                    m.step(u, 0.2, 0.01)
                link.update(level=m.h, sp=60, drain=0.2, run=True, estop=False)
                time.sleep(0.05)
            self.assertLess(abs(m.h - 60), 3.0, f"nivel final {m.h:.2f}")
            link.stop()
            time.sleep(3)
            self.assertTrue(get_bool(bytearray(db), 20, 0), "CommFault nu a fost semnalat")
        finally:
            stop.set()
            link.stop()
            srv.stop()


if __name__ == "__main__":
    unittest.main(verbosity=2)
