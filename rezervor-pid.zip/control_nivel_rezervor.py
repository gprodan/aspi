#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Control nivel lichid în rezervor — regulator PID în Python cu interfață customtkinter.

Două surse de proces:
  • Simulare locală  – modelul rezervorului rulează în aplicație (același model ca în scena 3D):
        dh/dt = 8·u − 1.2·d·√h      h ∈ [0, 100] %, u = deschidere valvă umplere, d = valvă golire
  • Scenă 3D         – aplicația este CLIENT al paginii rezervor-pid.html: o deschide (fișier local sau
                       URL, ex. GitHub Pages) într-un Chromium controlat prin Playwright și citește/scrie
                       direct prin window.tankAPI.get()/set(). Nu este nevoie de server.

Două moduri de reglare (pentru scena 3D):
  • PID Python  – Python calculează comanda u și o trimite scenei ({"fill": u}); scena doar execută.
                  Necesită versiunea actualizată a paginii (rezervor-pid.html cu suport „mode/fill”).
  • PID scenă   – PID-ul rulează în pagină; Python trimite consemnul, Kp/Ki/Kd, perturbația și comenzile.
  • PID PLC     – regulatorul rulează în PLC (TIA Portal, PID_Compact) simulat cu PLCSIM; Python este
                  gateway prin snap7 (PUT/GET): trimite nivelul/consemnul/starea în DB și aduce ieșirea PID
                  ca deschidere a valvei de umplere. Structura DB-ului este descrisă în clasa S7Link.

Dependențe:  pip install customtkinter playwright python-snap7
             playwright install chromium
Rulare:      python control_nivel_rezervor.py
"""
import csv
import math
import queue
import threading
import time
from collections import deque
from pathlib import Path

import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox


def clamp(x, a, b):
    return max(a, min(b, x))


# ============================================================================ PROCES + REGULATOR
class TankModel:
    """Modelul rezervorului (identic cu cel din scena 3D)."""
    QIN_MAX = 8.0     # %/s la valvă de umplere complet deschisă
    KOUT = 1.2        # coeficient de golire (lege Torricelli)

    def __init__(self, h0=10.0):
        self.h = h0

    def step(self, u, drain, dt):
        dh = self.QIN_MAX * u - self.KOUT * drain * math.sqrt(max(self.h, 0.0))
        self.h = clamp(self.h + dh * dt, 0.0, 100.0)
        return self.h


class PID:
    """PID discret, eroare normalizată (sp−h)/100 (aceeași scară cu scena 3D, deci aceleași câștiguri).
    - derivata pe măsură (fără „lovitură” la schimbarea consemnului)
    - filtru de ordinul I pe derivată
    - anti-windup prin integrare condiționată (integrarea se oprește când ieșirea e saturată
      și eroarea ar împinge-o și mai mult în saturație)"""

    def __init__(self, kp=5.0, ki=0.3, kd=1.0, u_min=0.0, u_max=1.0, tf=0.3):
        self.kp, self.ki, self.kd = kp, ki, kd
        self.u_min, self.u_max, self.tf = u_min, u_max, tf
        self.reset()

    def reset(self, y=None):
        self.i = 0.0
        self.prev_y = y
        self.d = 0.0
        self.p_term = self.i_term = self.d_term = 0.0

    def update(self, sp, y, dt):
        if dt <= 0:
            dt = 1e-3
        e = (sp - y) / 100.0
        # derivata pe măsură, filtrată
        if self.prev_y is None:
            d_raw = 0.0
        else:
            d_raw = -(y - self.prev_y) / 100.0 / dt
        a = dt / (self.tf + dt) if self.tf > 0 else 1.0
        self.d += a * (d_raw - self.d)
        self.prev_y = y

        i_new = self.i + e * dt
        u_try = self.kp * e + self.ki * i_new + self.kd * self.d
        saturated_hi = u_try > self.u_max and e > 0
        saturated_lo = u_try < self.u_min and e < 0
        if not (saturated_hi or saturated_lo):
            self.i = i_new

        self.p_term = self.kp * e
        self.i_term = self.ki * self.i
        self.d_term = self.kd * self.d
        return clamp(self.p_term + self.i_term + self.d_term, self.u_min, self.u_max)


class StepMetrics:
    """Indicatori de calitate pentru ultimul salt de consemn: timp de creștere (10–90 %),
    suprareglaj, timp de stabilizare (bandă ±2 % din amplitudinea saltului) și eroare staționară."""

    def __init__(self):
        self.active = False
        self.sp_prev = None

    def observe(self, t, sp, h, running):
        if not running:
            self.active = False
            self.sp_prev = sp
            return
        if self.sp_prev is None or abs(sp - self.sp_prev) > 0.25 or not self.active:
            self.active = True
            self.t0, self.h0, self.sp = t, h, sp
            self.amp = sp - h
            self.t10 = self.t90 = None
            self.peak = 0.0
            self.last_out = t
            self.err_hist = deque()
        self.sp_prev = sp
        if abs(self.amp) < 1.0:
            return
        sgn = 1 if self.amp > 0 else -1
        frac = (h - self.h0) / self.amp
        if self.t10 is None and frac >= 0.1:
            self.t10 = t
        if self.t90 is None and frac >= 0.9:
            self.t90 = t
        self.peak = max(self.peak, sgn * (h - self.sp))
        band = max(0.02 * abs(self.amp), 0.2)
        if abs(h - self.sp) > band:
            self.last_out = t
        self.err_hist.append((t, self.sp - h))
        while self.err_hist and t - self.err_hist[0][0] > 5.0:
            self.err_hist.popleft()

    def summary(self, t):
        if not self.active or abs(self.amp) < 1.0:
            return {"tr": "—", "os": "—", "ts": "—", "ess": "—"}
        tr = f"{self.t90 - self.t10:.1f} s" if self.t10 and self.t90 else "—"
        os_ = f"{max(self.peak, 0) / abs(self.amp) * 100:.1f} %"
        settled_for = t - self.last_out
        if settled_for >= 3.0:
            ts = f"{self.last_out - self.t0:.1f} s"
            ess = sum(e for _, e in self.err_hist) / max(len(self.err_hist), 1)
            ess = f"{ess:+.2f} %"
        else:
            ts, ess = "în curs…", "—"
        return {"tr": tr, "os": os_, "ts": ts, "ess": ess}


# ============================================================================ CLIENT PAGINĂ
class PageClient:
    """Client al paginii rezervor-pid.html. Deschide pagina (fișier local sau URL, ex. GitHub Pages)
    într-un Chromium controlat prin Playwright și comunică direct cu API-ul expus de pagină:
        window.tankAPI.get()   -> telemetrie {level, sp, kp, ki, kd, drain, fill, state, mode, t}
        window.tankAPI.set(m)  -> comenzi/parametri {sp, kp, ki, kd, drain, cmd, mode, fill}
    Nu este nevoie de niciun server. Totul rulează într-un fir separat; evenimentele ajung în `events`."""

    POLL_MS = 50

    def __init__(self, events: queue.Queue):
        self.events = events
        self.out = queue.Queue()
        self.thread = None
        self._stop = threading.Event()
        self.running = False        # firul clientului este activ
        self.connected = False      # pagina este încărcată și tankAPI este disponibil

    @staticmethod
    def to_url(target):
        t = target.strip().strip('"')
        if "://" in t:
            return t
        return Path(t).expanduser().resolve().as_uri()

    def start(self, target):
        if self.running:
            return
        try:
            url = self.to_url(target)
        except Exception as e:  # noqa
            self.events.put(("status", f"adresă invalidă: {e}"))
            return
        self._stop.clear()
        self.running = True
        self.events.put(("link", True))
        self.thread = threading.Thread(target=self._run, args=(url,), daemon=True)
        self.thread.start()

    def _run(self, url):
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.events.put(("status", "lipsește Playwright: pip install playwright  și  playwright install chromium"))
            self._finish()
            return
        try:
            with sync_playwright() as pw:
                self.events.put(("status", "pornesc browserul…"))
                browser = pw.chromium.launch(headless=False, args=["--start-maximized"])
                page = browser.new_page(no_viewport=True)
                page.goto(url)
                page.wait_for_function("() => window.tankAPI !== undefined", timeout=20000)
                self.connected = True
                self.events.put(("connected", True))
                self.events.put(("status", f"conectat la {url}"))
                while not self._stop.is_set():
                    while True:                       # comenzi în așteptare -> pagină
                        try:
                            msg = self.out.get_nowait()
                        except queue.Empty:
                            break
                        page.evaluate("m => window.tankAPI.set(m)", msg)
                    tel = page.evaluate("() => window.tankAPI.get()")
                    if isinstance(tel, dict):
                        self.events.put(("tel", tel))
                    page.wait_for_timeout(self.POLL_MS)
                try:                                  # la deconectare predăm controlul PID-ului din scenă
                    page.evaluate("m => window.tankAPI.set(m)", {"mode": "int"})
                except Exception:
                    pass
                browser.close()
                self.events.put(("status", "deconectat"))
        except Exception as e:  # noqa  (inclusiv închiderea ferestrei browserului de către utilizator)
            msg = str(e).splitlines()[0] if str(e) else type(e).__name__
            if "wait_for_function" in msg or "Timeout" in msg:
                msg = ("pagina nu expune window.tankAPI (verificați fișierul/URL-ul și conexiunea "
                       "la internet pentru three.js)")
            elif "closed" in msg.lower() or "target" in msg.lower():
                msg = "pagina/browserul a fost închis"
            self.events.put(("status", f"deconectat: {msg}"))
        finally:
            self._finish()

    def _finish(self):
        self.connected = False
        self.running = False
        self.events.put(("connected", False))
        self.events.put(("link", False))

    def send(self, obj):
        if self.connected:
            self.out.put(dict(obj))

    def stop(self):
        self._stop.set()


# ============================================================================ LEGĂTURĂ PLC (snap7)
class S7Link:
    """Gateway scenă <-> PLC (S7-1200/1500, PLCSIM prin NetToPLCsim sau PLCSIM Advanced), prin PUT/GET.

    DB-ul de schimb trebuie să fie NEOPTIMIZAT (fără „Optimized block access”). Structura implicită:
        ofs  tip   nume          sens
         0   Real  Level         gateway -> PLC   nivel măsurat în scenă [%]
         4   Real  Setpoint      gateway -> PLC   consemn (potențiometrul din scenă) [%]
         8   Real  Drain         gateway -> PLC   deschidere valvă golire / perturbație [%]
        12   Int   Heartbeat     gateway -> PLC   contor incrementat la fiecare ciclu (watchdog)
        14.0 Bool  Run           gateway -> PLC   instalația este pornită (START în scenă)
        14.1 Bool  EStop         gateway -> PLC   oprire de urgență activă
        15.0 Bool  Req_Start     PLC -> gateway   front crescător => comandă START în scenă
        15.1 Bool  Req_Stop      PLC -> gateway   front crescător => comandă STOP
        15.2 Bool  Req_EStop     PLC -> gateway   front crescător => oprire de urgență
        16   Real  Fill          PLC -> gateway   comanda valvei de umplere (ieșire PID) [%]
        20.0 Bool  CommFault     PLC (stare)      PLC-ul a detectat pierderea heartbeat-ului
        22   Int   HbCnt         PLC (intern)
    Gateway-ul scrie doar octeții 0…14 și citește 15…20, deci nu suprascrie niciodată ce scrie PLC-ul."""

    W_START, W_SIZE = 0, 15
    R_START, R_SIZE = 15, 6
    CYCLE = 0.05

    def __init__(self, events: queue.Queue):
        self.events = events
        self.lock = threading.Lock()
        self.out = {"level": 0.0, "sp": 0.0, "drain": 0.0, "run": False, "estop": False}
        self._stop = threading.Event()
        self.running = False
        self.connected = False

    def update(self, **kw):
        with self.lock:
            self.out.update(kw)

    def start(self, ip, rack, slot, db, port=102):
        if self.running:
            return
        self._stop.clear()
        self.running = True
        self.events.put(("plc_link", True))
        threading.Thread(target=self._run, args=(ip, rack, slot, db, port), daemon=True).start()

    def stop(self):
        self._stop.set()

    def _run(self, ip, rack, slot, db, port):
        try:
            import snap7
            from snap7.util import get_bool, get_real, set_bool, set_int, set_real
        except ImportError:
            self.events.put(("plc_status", "lipsește snap7: pip install python-snap7"))
            self._finish()
            return
        cli = snap7.client.Client()
        hb = 0
        try:
            cli.connect(ip, rack, slot, port)
            self.connected = True
            self.events.put(("plc_status", f"conectat la {ip}:{port} (rack {rack}, slot {slot}), DB{db}"))
            wbuf = bytearray(self.W_SIZE)
            errors = 0
            while not self._stop.is_set():
                t0 = time.monotonic()
                with self.lock:
                    o = dict(self.out)
                hb = (hb + 1) % 32768
                set_real(wbuf, 0, float(o["level"]))
                set_real(wbuf, 4, float(o["sp"]))
                set_real(wbuf, 8, float(o["drain"]) * 100.0)
                set_int(wbuf, 12, hb)
                set_bool(wbuf, 14, 0, bool(o["run"]))
                set_bool(wbuf, 14, 1, bool(o["estop"]))
                try:
                    cli.db_write(db, self.W_START, wbuf)
                    r = cli.db_read(db, self.R_START, self.R_SIZE)
                    errors = 0
                except Exception as e:  # noqa
                    errors += 1
                    if errors >= 5:
                        raise
                    continue
                self.events.put(("plc", {
                    "req_start": get_bool(r, 0, 0), "req_stop": get_bool(r, 0, 1), "req_estop": get_bool(r, 0, 2),
                    "fill": get_real(r, 1), "comm_fault": get_bool(r, 5, 0), "hb": hb}))
                time.sleep(max(0.0, self.CYCLE - (time.monotonic() - t0)))
            self.events.put(("plc_status", "deconectat"))
        except Exception as e:  # noqa
            msg = str(e).strip() or type(e).__name__
            self.events.put(("plc_status", f"eroare PLC: {msg}"))
        finally:
            try:
                cli.disconnect()
            except Exception:
                pass
            self._finish()

    def _finish(self):
        self.connected = False
        self.running = False
        self.events.put(("plc", None))
        self.events.put(("plc_link", False))


# ============================================================================ INTERFAȚA
COL = {"bg": "#0f1720", "panel": "#1b2633", "grid": "#26384a", "text": "#e6edf3", "mut": "#8b9bb0",
       "sp": "#f6c344", "h": "#3fb6ff", "u": "#2ecc71", "drain": "#ff7a59"}
STATE_TXT = {"RUN": "ÎN FUNCȚIUNE", "STOP": "OPRIT", "ESTOP": "OPRIRE DE URGENȚĂ"}
STATE_COL = {"RUN": "#1f6b38", "STOP": "#26384a", "ESTOP": "#8e1b1b"}


class ParamRow(ctk.CTkFrame):
    """Etichetă + câmp numeric + cursor, sincronizate."""

    def __init__(self, master, text, lo, hi, val, steps, fmt, on_change):
        super().__init__(master, fg_color="transparent")
        self.lo, self.hi, self.fmt, self.on_change = lo, hi, fmt, on_change
        self.columnconfigure(0, weight=1)
        ctk.CTkLabel(self, text=text, anchor="w", text_color=COL["mut"]).grid(row=0, column=0, sticky="w")
        self.entry = ctk.CTkEntry(self, width=70, justify="right")
        self.entry.grid(row=0, column=1, sticky="e")
        self.entry.bind("<Return>", self._entry)
        self.entry.bind("<FocusOut>", self._entry)
        self.slider = ctk.CTkSlider(self, from_=lo, to=hi, number_of_steps=steps, command=self._slide)
        self.slider.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(2, 6))
        self.set(val)

    def _entry(self, _=None):
        try:
            v = clamp(float(self.entry.get().replace(",", ".")), self.lo, self.hi)
        except ValueError:
            v = self.value
        self.set(v)
        self.on_change(v)

    def _slide(self, v):
        self.value = float(v)
        self._show()
        self.on_change(self.value)

    def _show(self):
        self.entry.delete(0, "end")
        self.entry.insert(0, self.fmt.format(self.value))

    def set(self, v):
        self.value = float(v)
        self.slider.set(self.value)
        try:
            focused = self.focus_get() is self.entry._entry
        except (KeyError, AttributeError):
            focused = False
        if not focused:
            self._show()


class App(ctk.CTk):
    TICK_MS = 50
    TREND_WINDOW = 60.0     # s afișate pe grafic

    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        self.title("Control nivel rezervor — PID")
        self.geometry("1280x780")
        self.minsize(1050, 660)

        # stare
        self.p = {"sp": 60.0, "kp": 5.0, "ki": 0.3, "kd": 1.0, "drain": 0.2}
        self.pid = PID(self.p["kp"], self.p["ki"], self.p["kd"])
        self.model = TankModel(10.0)
        self.metrics = StepMetrics()
        self.events = queue.Queue()
        self.bridge = PageClient(self.events)
        self.plc = S7Link(self.events)
        self.plc_data = None
        self.plc_prev = {}
        self.source = "local"          # local | scene
        self.ctrl = "python"           # python | scene
        self.state_ = "STOP"
        self.h = self.model.h
        self.u = 0.0
        self.drain_eff = self.p["drain"]
        self.tel = None
        self.tel_new = False
        self.tel_prev_t = None
        self.tel_last = 0.0
        self.sent_at = {}              # cheie -> momentul ultimei trimiteri (pentru sincronizare bidirecțională)
        self.t_start = time.monotonic()
        self.t_last = self.t_start
        self.trend = deque()
        self.log = []
        self.log_on = False
        self._trend_acc = 0.0

        self._build()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(self.TICK_MS, self._tick)

    # ------------------------------------------------------------------ construire UI
    def _build(self):
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        left = ctk.CTkScrollableFrame(self, width=330, label_text="Panou de control")
        left.grid(row=0, column=0, sticky="nsew", padx=(10, 5), pady=10)
        left.columnconfigure(0, weight=1)
        r = 0

        # sursă proces
        ctk.CTkLabel(left, text="Proces", font=ctk.CTkFont(weight="bold")).grid(row=r, column=0, sticky="w"); r += 1
        self.seg_src = ctk.CTkSegmentedButton(left, values=["Simulare locală", "Scenă 3D"], command=self._set_source)
        self.seg_src.set("Simulare locală")
        self.seg_src.grid(row=r, column=0, sticky="ew", pady=(2, 6)); r += 1

        ctk.CTkLabel(left, text="Pagina scenei (fișier sau URL)", text_color=COL["mut"], anchor="w").grid(
            row=r, column=0, sticky="w"); r += 1
        wsf = ctk.CTkFrame(left, fg_color="transparent")
        wsf.grid(row=r, column=0, sticky="ew"); r += 1
        wsf.columnconfigure(0, weight=1)
        self.e_url = ctk.CTkEntry(wsf)
        self.e_url.insert(0, str(Path(__file__).with_name("rezervor-pid.html")))
        self.e_url.grid(row=0, column=0, sticky="ew", padx=(0, 4))
        ctk.CTkButton(wsf, text="…", width=30, command=self._browse).grid(row=0, column=1)
        self.b_srv = ctk.CTkButton(left, text="Conectare la scenă", command=self._toggle_link)
        self.b_srv.grid(row=r, column=0, sticky="ew", pady=(4, 0)); r += 1
        self.l_ws = ctk.CTkLabel(left, text="deconectat", text_color=COL["mut"], anchor="w",
                                 wraplength=300, justify="left")
        self.l_ws.grid(row=r, column=0, sticky="ew"); r += 1

        ctk.CTkLabel(left, text="Regulator", font=ctk.CTkFont(weight="bold")).grid(row=r, column=0, sticky="w", pady=(8, 0)); r += 1
        self.seg_ctrl = ctk.CTkSegmentedButton(left, values=["PID Python", "PID scenă", "PID PLC"],
                                               command=self._set_ctrl)
        self.seg_ctrl.set("PID Python")
        self.seg_ctrl.grid(row=r, column=0, sticky="ew", pady=(2, 6)); r += 1

        # PLC (snap7)
        pf = ctk.CTkFrame(left)
        pf.grid(row=r, column=0, sticky="ew", pady=(2, 6)); r += 1
        pf.columnconfigure((1, 3), weight=1)
        self.plc_e = {}
        for i, (k, t, v) in enumerate([("ip", "IP", "127.0.0.1"), ("port", "Port", "102"),
                                       ("rack", "Rack", "0"), ("slot", "Slot", "1"), ("db", "DB nr.", "1")]):
            rr, cc = (0, 0) if k == "ip" else ((1 + (i - 1) // 2), ((i - 1) % 2) * 2)
            ctk.CTkLabel(pf, text=t, text_color=COL["mut"]).grid(row=rr, column=cc, sticky="w", padx=(8, 4), pady=2)
            e = ctk.CTkEntry(pf, width=60)
            e.insert(0, v)
            e.grid(row=rr, column=cc + 1, columnspan=3 if k == "ip" else 1, sticky="ew", padx=(0, 8), pady=2)
            self.plc_e[k] = e
        self.b_plc = ctk.CTkButton(pf, text="Conectare PLC", command=self._toggle_plc)
        self.b_plc.grid(row=4, column=0, columnspan=4, sticky="ew", padx=8, pady=(4, 2))
        self.l_plc = ctk.CTkLabel(pf, text="PLC deconectat", text_color=COL["mut"], anchor="w",
                                  wraplength=290, justify="left")
        self.l_plc.grid(row=5, column=0, columnspan=4, sticky="ew", padx=8, pady=(0, 4))

        # comenzi
        bf = ctk.CTkFrame(left, fg_color="transparent")
        bf.grid(row=r, column=0, sticky="ew", pady=(6, 4)); r += 1
        for i in range(3):
            bf.columnconfigure(i, weight=1)
        ctk.CTkButton(bf, text="START", fg_color="#2e9e4f", hover_color="#25803f",
                      command=lambda: self._cmd("start")).grid(row=0, column=0, sticky="ew", padx=2)
        ctk.CTkButton(bf, text="STOP", fg_color="#c78a12", hover_color="#a3700e",
                      command=lambda: self._cmd("stop")).grid(row=0, column=1, sticky="ew", padx=2)
        self.b_au = ctk.CTkButton(bf, text="AU", fg_color="#d32f2f", hover_color="#ab2626",
                                  command=lambda: self._cmd("reset" if self.state_ == "ESTOP" else "estop"))
        self.b_au.grid(row=0, column=2, sticky="ew", padx=2)
        self.l_state = ctk.CTkLabel(left, text="OPRIT", corner_radius=6, fg_color=STATE_COL["STOP"],
                                    font=ctk.CTkFont(weight="bold"), height=32)
        self.l_state.grid(row=r, column=0, sticky="ew", pady=4); r += 1

        # parametri
        self.rows = {}
        defs = [("sp", "Nivel țintă [%]", 0, 100, 200, "{:.1f}"),
                ("kp", "Kp", 0, 20, 200, "{:.2f}"),
                ("ki", "Ki [1/s]", 0, 2, 200, "{:.3f}"),
                ("kd", "Kd [s]", 0, 10, 100, "{:.2f}"),
                ("drain", "Valvă golire — perturbație [0…1]", 0, 1, 100, "{:.2f}")]
        for k, t, lo, hi, st, fmt in defs:
            row = ParamRow(left, t, lo, hi, self.p[k], st, fmt, lambda v, k=k: self._param(k, v))
            row.grid(row=r, column=0, sticky="ew"); r += 1
            self.rows[k] = row

        # valori instantanee
        vf = ctk.CTkFrame(left)
        vf.grid(row=r, column=0, sticky="ew", pady=6); r += 1
        vf.columnconfigure(1, weight=1)
        self.vals = {}
        for i, (k, t, c) in enumerate([("h", "Nivel curent", COL["h"]), ("e", "Eroare", COL["text"]),
                                       ("u", "Valvă umplere (u)", COL["u"]), ("pid", "P / I / D", COL["mut"])]):
            ctk.CTkLabel(vf, text=t, text_color=COL["mut"]).grid(row=i, column=0, sticky="w", padx=8)
            lab = ctk.CTkLabel(vf, text="—", text_color=c, font=ctk.CTkFont(family="Consolas", size=13, weight="bold"))
            lab.grid(row=i, column=1, sticky="e", padx=8)
            self.vals[k] = lab

        # indicatori de calitate
        ctk.CTkLabel(left, text="Răspuns la ultimul salt de consemn", font=ctk.CTkFont(weight="bold")).grid(
            row=r, column=0, sticky="w", pady=(8, 0)); r += 1
        mf = ctk.CTkFrame(left)
        mf.grid(row=r, column=0, sticky="ew", pady=4); r += 1
        mf.columnconfigure(1, weight=1)
        self.mvals = {}
        for i, (k, t) in enumerate([("tr", "Timp de creștere (10–90 %)"), ("os", "Suprareglaj"),
                                    ("ts", "Timp de stabilizare (±2 %)"), ("ess", "Eroare staționară")]):
            ctk.CTkLabel(mf, text=t, text_color=COL["mut"]).grid(row=i, column=0, sticky="w", padx=8)
            lab = ctk.CTkLabel(mf, text="—", font=ctk.CTkFont(family="Consolas", size=13))
            lab.grid(row=i, column=1, sticky="e", padx=8)
            self.mvals[k] = lab

        # înregistrare
        lf = ctk.CTkFrame(left, fg_color="transparent")
        lf.grid(row=r, column=0, sticky="ew", pady=(8, 2)); r += 1
        lf.columnconfigure((0, 1), weight=1)
        self.b_log = ctk.CTkButton(lf, text="● Înregistrare", command=self._toggle_log, fg_color="#2a5d8a")
        self.b_log.grid(row=0, column=0, sticky="ew", padx=2)
        ctk.CTkButton(lf, text="Export CSV", command=self._export).grid(row=0, column=1, sticky="ew", padx=2)
        self.l_log = ctk.CTkLabel(left, text="0 eșantioane", text_color=COL["mut"])
        self.l_log.grid(row=r, column=0, sticky="w"); r += 1

        # zona dreaptă: rezervor + grafic
        right = ctk.CTkFrame(self, fg_color=COL["panel"])
        right.grid(row=0, column=1, sticky="nsew", padx=(5, 10), pady=10)
        right.columnconfigure(1, weight=1)
        right.rowconfigure(0, weight=1)
        self.cv_tank = tk.Canvas(right, width=300, bg=COL["bg"], highlightthickness=0)
        self.cv_tank.grid(row=0, column=0, sticky="ns", padx=(10, 5), pady=10)
        self.cv_trend = tk.Canvas(right, bg=COL["bg"], highlightthickness=0)
        self.cv_trend.grid(row=0, column=1, sticky="nsew", padx=(5, 10), pady=10)

    # ------------------------------------------------------------------ acțiuni UI
    def _set_source(self, v):
        self.source = "scene" if v == "Scenă 3D" else "local"
        if self.source == "scene":
            if not self.bridge.running:
                self._toggle_link()
            self.state_ = "STOP"
        else:
            self.model.h = self.h
            self.state_ = "STOP"
        self.u = 0.0
        self.pid.reset(self.h)

    def _set_ctrl(self, v):
        self.ctrl = {"PID Python": "python", "PID scenă": "scene", "PID PLC": "plc"}[v]
        self.pid.reset(self.h)
        self._send({"mode": "int" if self.ctrl == "scene" else "ext"})
        if self.ctrl == "plc" and not self.plc.running:
            self._toggle_plc()

    def _toggle_plc(self):
        if self.plc.running:
            self.plc.stop()
            self.l_plc.configure(text="deconectare…")
            return
        try:
            ip = self.plc_e["ip"].get().strip()
            port, rack, slot, db = (int(self.plc_e[k].get()) for k in ("port", "rack", "slot", "db"))
        except ValueError:
            messagebox.showerror("PLC", "Port, rack, slot și DB trebuie să fie numere întregi.")
            return
        self.l_plc.configure(text=f"conectare la {ip}…")
        self.plc.start(ip, rack, slot, db, port)

    def _browse(self):
        fn = filedialog.askopenfilename(filetypes=[("Pagină HTML", "*.html *.htm"), ("Toate", "*.*")])
        if fn:
            self.e_url.delete(0, "end")
            self.e_url.insert(0, fn)

    def _toggle_link(self):
        if self.bridge.running:
            self.bridge.stop()
            self.l_ws.configure(text="deconectare…")
            return
        target = self.e_url.get().strip()
        if not target:
            messagebox.showerror("Scenă", "Indicați fișierul rezervor-pid.html sau URL-ul paginii.")
            return
        if self.source != "scene":
            self.seg_src.set("Scenă 3D")
            self.source = "scene"
            self.state_ = "STOP"
            self.u = 0.0
        self.bridge.start(target)

    def _cmd(self, c):
        if self.source == "local":
            if c == "start" and self.state_ == "STOP":
                self.state_ = "RUN"
                self.pid.reset(self.h)
            elif c == "stop" and self.state_ == "RUN":
                self.state_ = "STOP"
            elif c == "estop":
                self.state_ = "ESTOP"
            elif c == "reset" and self.state_ == "ESTOP":
                self.state_ = "STOP"
        else:
            self._send({"cmd": c})

    def _param(self, k, v):
        self.p[k] = v
        self.pid.kp, self.pid.ki, self.pid.kd = self.p["kp"], self.p["ki"], self.p["kd"]
        self._send({k: v})

    def _send(self, obj):
        if self.source == "scene" and self.bridge.connected:
            now = time.monotonic()
            for k in obj:
                self.sent_at[k] = now
            self.bridge.send(obj)

    def _toggle_log(self):
        self.log_on = not self.log_on
        self.b_log.configure(text="■ Oprește înregistrarea" if self.log_on else "● Înregistrare",
                             fg_color="#8e1b1b" if self.log_on else "#2a5d8a")

    def _export(self):
        if not self.log:
            messagebox.showinfo("Export", "Nu există date înregistrate.")
            return
        fn = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")],
                                          initialfile=time.strftime("rezervor_%Y%m%d_%H%M%S.csv"))
        if not fn:
            return
        with open(fn, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["t_s", "consemn_pct", "nivel_pct", "u_umplere", "d_golire", "kp", "ki", "kd", "stare", "sursa", "regulator"])
            w.writerows(self.log)
        messagebox.showinfo("Export", f"Salvat {len(self.log)} eșantioane în\n{fn}")

    # ------------------------------------------------------------------ bucla principală
    def _drain_events(self):
        while True:
            try:
                kind, data = self.events.get_nowait()
            except queue.Empty:
                break
            if kind == "status":
                self.l_ws.configure(text=data)
            elif kind == "link":
                self.b_srv.configure(text="Deconectare" if data else "Conectare la scenă",
                                     fg_color="#8e1b1b" if data else ("#3a7ebf", "#1f538d"))
            elif kind == "connected":
                self.tel = None
                if data:   # la conectare: impunem modul de reglare și parametrii din Python
                    self._send({"mode": "int" if self.ctrl == "scene" else "ext", "sp": self.p["sp"],
                                "kp": self.p["kp"], "ki": self.p["ki"], "kd": self.p["kd"], "drain": self.p["drain"]})
            elif kind == "plc_status":
                self.l_plc.configure(text=data)
            elif kind == "plc_link":
                self.b_plc.configure(text="Deconectare PLC" if data else "Conectare PLC",
                                     fg_color="#8e1b1b" if data else ("#3a7ebf", "#1f538d"))
            elif kind == "plc":
                self._on_plc(data)
            elif kind == "tel":
                self.tel = data
                self.tel_new = True
                self.tel_last = time.monotonic()

    def _plc_u(self):
        """Comanda valvei de umplere din PLC (0…1). Fără legătură sau cu watchdog declanșat -> 0."""
        d = self.plc_data
        if not d or d["comm_fault"]:
            return 0.0
        return clamp(d["fill"] / 100.0, 0.0, 1.0)

    def _on_plc(self, d):
        self.plc_data = d
        if d is None:
            self.plc_prev = {}
            return
        # cereri din programul PLC (front crescător) -> comenzi în scenă / simulare
        for key, c in (("req_estop", "estop"), ("req_stop", "stop"), ("req_start", "start")):
            if d[key] and not self.plc_prev.get(key, False) and self.ctrl == "plc":
                self._cmd(c)
        self.plc_prev = d
        self.l_plc.configure(text=f"PLC: ieșire PID {d['fill']:.1f} %" +
                             ("  ⚠ CommFault (watchdog)" if d["comm_fault"] else "  ✓ comunicație OK"))

    def _sync_from_scene(self, now):
        """Dacă utilizatorul a mutat un cursor în scenă, preluăm valoarea (sincronizare bidirecțională)."""
        for k in ("sp", "kp", "ki", "kd", "drain"):
            v = self.tel.get(k)
            if isinstance(v, (int, float)) and abs(v - self.p[k]) > 1e-6 and now - self.sent_at.get(k, 0) > 0.8:
                self.p[k] = float(v)
                self.rows[k].set(v)
        self.pid.kp, self.pid.ki, self.pid.kd = self.p["kp"], self.p["ki"], self.p["kd"]

    def _tick(self):
        now = time.monotonic()
        dt = min(now - self.t_last, 0.2)
        self.t_last = now
        self._drain_events()

        if self.source == "local":
            if self.state_ != "RUN":
                self.u = 0.0
            elif self.ctrl == "plc":
                self.u = self._plc_u()
            else:
                self.u = self.pid.update(self.p["sp"], self.h, dt)
            self.drain_eff = 1.0 if self.state_ == "ESTOP" else self.p["drain"]
            for _ in range(5):
                self.model.step(self.u, self.drain_eff, dt / 5)
            self.h = self.model.h
        else:
            stale = self.tel is None or now - self.tel_last > 1.5
            if not stale and self.tel_new:
                self.tel_new = False
                self._sync_from_scene(now)
                prev_state = self.state_
                self.h = float(self.tel.get("level", self.h))
                self.state_ = self.tel.get("state", self.state_)
                tt = self.tel.get("t")
                tdt = (tt - self.tel_prev_t) / 1000.0 if (tt and self.tel_prev_t) else 0.2
                self.tel_prev_t = tt
                if self.ctrl == "plc":
                    if self.tel.get("mode") != "ext":
                        self._send({"mode": "ext"})
                    self.u = self._plc_u() if self.state_ == "RUN" else 0.0
                    if self.state_ == "RUN":
                        self._send({"fill": round(self.u, 4)})
                elif self.ctrl == "python":
                    if self.tel.get("mode") != "ext":
                        self._send({"mode": "ext"})
                    if self.state_ == "RUN":
                        if prev_state != "RUN":
                            self.pid.reset(self.h)
                        self.u = self.pid.update(self.p["sp"], self.h, clamp(tdt, 0.01, 1.0))
                        self._send({"fill": round(self.u, 4)})
                    else:
                        self.u = 0.0
                else:
                    self.u = float(self.tel.get("fill", 0.0))
                self.drain_eff = 1.0 if self.state_ == "ESTOP" else self.p["drain"]
            if stale:
                self.u = 0.0

        # date proces -> PLC (le scrie firul S7Link la fiecare ciclu)
        self.plc.update(level=self.h, sp=self.p["sp"], drain=self.p["drain"],
                        run=self.state_ == "RUN", estop=self.state_ == "ESTOP")

        t = now - self.t_start
        self.metrics.observe(t, self.p["sp"], self.h, self.state_ == "RUN")
        self._trend_acc += dt
        if self._trend_acc >= 0.1:
            self._trend_acc = 0.0
            self.trend.append((t, self.p["sp"], self.h, self.u * 100))
            while self.trend and t - self.trend[0][0] > self.TREND_WINDOW:
                self.trend.popleft()
            if self.log_on:
                self.log.append([f"{t:.2f}", f"{self.p['sp']:.2f}", f"{self.h:.3f}", f"{self.u:.4f}",
                                 f"{self.drain_eff:.3f}", self.p["kp"], self.p["ki"], self.p["kd"],
                                 self.state_, self.source, self.ctrl])

        self._update_labels(t)
        self._draw_tank()
        self._draw_trend(t)
        self.after(self.TICK_MS, self._tick)

    # ------------------------------------------------------------------ afișare
    def _update_labels(self, t):
        e = self.p["sp"] - self.h
        self.vals["h"].configure(text=f"{self.h:6.2f} %")
        self.vals["e"].configure(text=f"{e:+6.2f} %")
        self.vals["u"].configure(text=f"{self.u * 100:5.1f} %")
        if self.ctrl == "plc":
            self.vals["pid"].configure(text="(calculat în PLC)")
        elif self.ctrl == "python" or self.source == "local":
            self.vals["pid"].configure(text=f"{self.pid.p_term:+.2f} / {self.pid.i_term:+.2f} / {self.pid.d_term:+.2f}")
        else:
            self.vals["pid"].configure(text="(calculat în scenă)")
        txt = STATE_TXT.get(self.state_, self.state_)
        if self.source == "scene" and (self.tel is None or time.monotonic() - self.tel_last > 1.5):
            txt = "FĂRĂ DATE DE LA SCENĂ"
        self.l_state.configure(text=txt, fg_color=STATE_COL.get(self.state_, STATE_COL["STOP"]))
        self.b_au.configure(text="RESET AU" if self.state_ == "ESTOP" else "AU")
        for k, v in self.metrics.summary(t).items():
            self.mvals[k].configure(text=v)
        self.l_log.configure(text=f"{len(self.log)} eșantioane" + (" — înregistrez" if self.log_on else ""))

    def _draw_tank(self):
        c = self.cv_tank
        c.delete("all")
        W, H = c.winfo_width(), c.winfo_height()
        if W < 50 or H < 100:
            return
        x0, x1 = W * 0.28, W * 0.72
        y0, y1 = 70, H - 70
        th = y1 - y0
        lvl_y = y1 - self.h / 100 * th
        sp_y = y1 - self.p["sp"] / 100 * th
        # conductă umplere + valvă
        c.create_line(20, 35, W * 0.42, 35, W * 0.42, y0 + 4, fill="#1f5fa8", width=8, capstyle="round")
        self._valve(c, W * 0.22, 35, self.u, "UMPLERE")
        if self.u > 0.02:
            c.create_line(W * 0.42, y0 + 4, W * 0.42, lvl_y, fill=COL["h"], width=2 + 4 * self.u, dash=(4, 3))
        # rezervor
        c.create_rectangle(x0, lvl_y, x1, y1, fill="#1e6fbf", outline="")
        c.create_line(x0, lvl_y, x1, lvl_y, fill="#7cc8ff", width=2)
        c.create_rectangle(x0, y0, x1, y1, outline="#b7c0c9", width=3)
        # scară
        for p in range(0, 101, 10):
            y = y1 - p / 100 * th
            c.create_line(x1, y, x1 + (12 if p % 20 == 0 else 7), y, fill=COL["mut"])
            if p % 20 == 0:
                c.create_text(x1 + 16, y, text=f"{p}", anchor="w", fill=COL["mut"], font=("Segoe UI", 9))
        # consemn
        c.create_line(x0 - 14, sp_y, x1, sp_y, fill=COL["sp"], dash=(6, 4), width=2)
        c.create_polygon(x0 - 16, sp_y - 6, x0 - 4, sp_y, x0 - 16, sp_y + 6, fill=COL["sp"])
        c.create_text((x0 + x1) / 2, (lvl_y + y1) / 2 if self.h > 8 else y1 - 12, text=f"{self.h:.1f} %",
                      fill="white", font=("Segoe UI", 14, "bold"))
        # golire
        c.create_line((x0 + x1) / 2, y1, (x0 + x1) / 2, y1 + 30, W - 20, y1 + 30, fill="#1f5fa8", width=8)
        self._valve(c, W * 0.74, y1 + 30, self.drain_eff, "GOLIRE")
        # lampă stare
        col = {"RUN": "#2ecc71", "ESTOP": "#ff2222"}.get(self.state_, "#555555")
        c.create_oval(W - 34, 14, W - 14, 34, fill=col, outline="#222")

    @staticmethod
    def _valve(c, x, y, o, name):
        g = int(200 * o)
        col = f"#{200 - g:02x}{g + 40:02x}40"
        c.create_polygon(x - 14, y - 10, x + 14, y + 10, x + 14, y - 10, x - 14, y + 10, fill=col, outline="#ddd")
        c.create_line(x, y, x, y - 16, fill="#ddd", width=2)
        c.create_line(x - 9, y - 16, x + 9, y - 16, fill="#ddd", width=3)
        c.create_text(x, y + 22, text=f"{name} {o * 100:.0f}%", fill=COL["mut"], font=("Segoe UI", 9))

    def _draw_trend(self, t):
        c = self.cv_trend
        c.delete("all")
        W, H = c.winfo_width(), c.winfo_height()
        if W < 100 or H < 100:
            return
        L, R, T, B = 50, W - 15, 35, H - 35
        c.create_text(L, 14, text="Evoluție în timp", anchor="w", fill=COL["text"], font=("Segoe UI", 11, "bold"))
        legend = [("consemn", COL["sp"]), ("nivel", COL["h"]), ("u umplere", COL["u"])]
        lx = R
        for name, col in reversed(legend):
            lx -= 8 * len(name) + 30
            c.create_line(lx, 14, lx + 18, 14, fill=col, width=3)
            c.create_text(lx + 22, 14, text=name, anchor="w", fill=COL["mut"], font=("Segoe UI", 9))
        for p in range(0, 101, 20):
            y = B - p / 100 * (B - T)
            c.create_line(L, y, R, y, fill=COL["grid"])
            c.create_text(L - 6, y, text=f"{p}%", anchor="e", fill=COL["mut"], font=("Segoe UI", 9))
        t0 = t - self.TREND_WINDOW
        for s in range(0, int(self.TREND_WINDOW) + 1, 10):
            x = L + s / self.TREND_WINDOW * (R - L)
            c.create_line(x, T, x, B, fill=COL["grid"])
            c.create_text(x, B + 14, text=f"{s - int(self.TREND_WINDOW)} s", fill=COL["mut"], font=("Segoe UI", 9))
        if len(self.trend) < 2:
            return
        for idx, col, w in ((3, COL["u"], 1), (1, COL["sp"], 2), (2, COL["h"], 2)):
            pts = []
            for row in self.trend:
                pts += [L + (row[0] - t0) / self.TREND_WINDOW * (R - L), B - clamp(row[idx], 0, 100) / 100 * (B - T)]
            c.create_line(*pts, fill=col, width=w)

    def _on_close(self):
        self.plc.stop()
        self.bridge.stop()                # clientul trimite {"mode":"int"} și închide browserul
        self.after(300, self.destroy)


if __name__ == "__main__":
    App().mainloop()
